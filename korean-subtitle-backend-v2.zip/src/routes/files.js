const express = require('express');
const multer = require('multer');
const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { authenticate, checkUsageLimit } = require('../middleware/auth');
const { supabase } = require('../db');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

// R2/S3 配置
const s3Client = new S3Client({
  region: 'auto',
  endpoint: process.env.R2_ENDPOINT || process.env.S3_ENDPOINT,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID || process.env.S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || process.env.S3_SECRET_ACCESS_KEY,
  },
});

const BUCKET_NAME = process.env.R2_BUCKET_NAME || process.env.S3_BUCKET_NAME;

// 内存存储（用于处理上传）
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['video/mp4', 'video/quicktime', 'video/avi', 'video/x-msvideo', 'audio/mpeg', 'audio/wav'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only video and audio files are allowed.'));
    }
  }
});

// 上传文件
router.post('/upload', authenticate, checkUsageLimit, upload.single('file'), async (req, res) => {
  try {
    const user = req.user;
    const file = req.file;
    
    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // 计算文件大小（MB）
    const fileSizeMB = file.size / (1024 * 1024);
    
    // 检查存储限制
    if (user.storage_used_mb + fileSizeMB > user.storage_limit_mb) {
      return res.status(403).json({ 
        error: 'Storage limit exceeded',
        used: user.storage_used_mb,
        limit: user.storage_limit_mb,
        required: fileSizeMB
      });
    }
    
    // 生成唯一文件名
    const filename = `${user.id}/${uuidv4()}-${file.originalname}`;
    
    // 上传到R2/S3
    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: filename,
      Body: file.buffer,
      ContentType: file.mimetype,
    });
    
    await s3Client.send(command);
    
    // 保存到数据库
    const { data: fileRecord, error } = await supabase
      .from('files')
      .insert([{
        user_id: user.id,
        filename: filename,
        original_name: file.originalname,
        size_mb: fileSizeMB,
        mime_type: file.mimetype,
        storage_path: filename,
      }])
      .select()
      .single();
    
    if (error) {
      console.error('Database error:', error);
      return res.status(500).json({ error: 'Failed to save file record' });
    }
    
    // 更新用户存储用量
    await supabase
      .from('users')
      .update({ 
        storage_used_mb: user.storage_used_mb + fileSizeMB,
        updated_at: new Date()
      })
      .eq('id', user.id);
    
    // 记录用量
    await supabase.from('usage_logs').insert([{
      user_id: user.id,
      action: 'upload',
      file_size_mb: fileSizeMB
    }]);
    
    res.json({
      message: 'File uploaded successfully',
      file: {
        id: fileRecord.id,
        originalName: file.originalname,
        sizeMB: fileSizeMB,
        mimeType: file.mimetype
      },
      storageUsed: user.storage_used_mb + fileSizeMB,
      storageLimit: user.storage_limit_mb
    });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: 'Upload failed', message: err.message });
  }
});

// 获取用户文件列表
router.get('/list', authenticate, async (req, res) => {
  try {
    const user = req.user;
    
    const { data: files, error } = await supabase
      .from('files')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .order('created_at', { ascending: false });
    
    if (error) {
      return res.status(500).json({ error: 'Failed to fetch files' });
    }
    
    res.json({
      files: files.map(f => ({
        id: f.id,
        originalName: f.original_name,
        sizeMB: f.size_mb,
        mimeType: f.mime_type,
        createdAt: f.created_at
      })),
      storageUsed: user.storage_used_mb,
      storageLimit: user.storage_limit_mb
    });
  } catch (err) {
    console.error('List files error:', err);
    res.status(500).json({ error: 'Failed to fetch files' });
  }
});

// 获取文件下载链接
router.get('/:fileId/download', authenticate, async (req, res) => {
  try {
    const user = req.user;
    const { fileId } = req.params;
    
    // 检查文件所有权
    const { data: file, error } = await supabase
      .from('files')
      .select('*')
      .eq('id', fileId)
      .eq('user_id', user.id)
      .single();
    
    if (error || !file) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    // 生成预签名URL（1小时有效）
    const command = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: file.storage_path,
    });
    
    const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
    
    res.json({
      downloadUrl: signedUrl,
      originalName: file.original_name
    });
  } catch (err) {
    console.error('Download error:', err);
    res.status(500).json({ error: 'Failed to generate download link' });
  }
});

// 删除文件
router.delete('/:fileId', authenticate, async (req, res) => {
  try {
    const user = req.user;
    const { fileId } = req.params;
    
    // 获取文件信息
    const { data: file, error } = await supabase
      .from('files')
      .select('*')
      .eq('id', fileId)
      .eq('user_id', user.id)
      .single();
    
    if (error || !file) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    // 从R2/S3删除
    const command = new DeleteObjectCommand({
      Bucket: BUCKET_NAME,
      Key: file.storage_path,
    });
    
    await s3Client.send(command);
    
    // 更新数据库状态
    await supabase
      .from('files')
      .update({ status: 'deleted' })
      .eq('id', fileId);
    
    // 更新用户存储用量
    await supabase
      .from('users')
      .update({ 
        storage_used_mb: Math.max(0, user.storage_used_mb - file.size_mb),
        updated_at: new Date()
      })
      .eq('id', user.id);
    
    res.json({
      message: 'File deleted successfully',
      freedSpace: file.size_mb
    });
  } catch (err) {
    console.error('Delete error:', err);
    res.status(500).json({ error: 'Failed to delete file' });
  }
});

module.exports = router;
