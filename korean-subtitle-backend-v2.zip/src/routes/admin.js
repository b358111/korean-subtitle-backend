const express = require('express');
const { supabase } = require('../db');

const router = express.Router();

// 简单的API Key验证（用于管理后台）
const verifyAdmin = (req, res, next) => {
  const apiKey = req.headers['x-admin-api-key'];
  
  if (apiKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  next();
};

// 获取所有用户统计
router.get('/users', verifyAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;
    
    const { data: users, error, count } = await supabase
      .from('users')
      .select('id, email, name, plan, monthly_minutes, used_minutes, storage_used_mb, storage_limit_mb, subscription_status, created_at', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) {
      return res.status(500).json({ error: 'Failed to fetch users' });
    }
    
    // 统计
    const stats = {
      total: count,
      byPlan: {},
      activeSubscriptions: 0
    };
    
    users.forEach(user => {
      stats.byPlan[user.plan] = (stats.byPlan[user.plan] || 0) + 1;
      if (user.subscription_status === 'active') {
        stats.activeSubscriptions++;
      }
    });
    
    res.json({
      users,
      stats,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: count,
        totalPages: Math.ceil(count / limit)
      }
    });
  } catch (err) {
    console.error('Admin users error:', err);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// 获取系统统计
router.get('/stats', verifyAdmin, async (req, res) => {
  try {
    // 用户统计
    const { data: userStats } = await supabase
      .from('users')
      .select('plan, subscription_status');
    
    // 用量统计（本月）
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    
    const { data: usageStats } = await supabase
      .from('usage_logs')
      .select('action, minutes_used, file_size_mb')
      .gte('created_at', startOfMonth.toISOString());
    
    // 收入统计
    const { data: paymentStats } = await supabase
      .from('payments')
      .select('amount, status')
      .eq('status', 'completed')
      .gte('created_at', startOfMonth.toISOString());
    
    // 计算统计
    const stats = {
      users: {
        total: userStats.length,
        byPlan: {},
        activeSubscriptions: 0
      },
      usage: {
        totalMinutes: 0,
        totalFiles: 0,
        totalUploadMB: 0
      },
      revenue: {
        thisMonth: 0,
        totalTransactions: paymentStats.length
      }
    };
    
    userStats.forEach(u => {
      stats.users.byPlan[u.plan] = (stats.users.byPlan[u.plan] || 0) + 1;
      if (u.subscription_status === 'active') stats.users.activeSubscriptions++;
    });
    
    usageStats.forEach(u => {
      stats.usage.totalMinutes += parseFloat(u.minutes_used || 0);
      stats.usage.totalUploadMB += parseFloat(u.file_size_mb || 0);
      if (u.action === 'upload') stats.usage.totalFiles++;
    });
    
    paymentStats.forEach(p => {
      stats.revenue.thisMonth += parseFloat(p.amount || 0);
    });
    
    res.json(stats);
  } catch (err) {
    console.error('Admin stats error:', err);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

// 更新用户计划
router.patch('/users/:userId/plan', verifyAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const { plan, monthlyMinutes, storageLimitMB } = req.body;
    
    const updateData = {
      updated_at: new Date()
    };
    
    if (plan) updateData.plan = plan;
    if (monthlyMinutes) updateData.monthly_minutes = monthlyMinutes;
    if (storageLimitMB) updateData.storage_limit_mb = storageLimitMB;
    
    const { data, error } = await supabase
      .from('users')
      .update(updateData)
      .eq('id', userId)
      .select()
      .single();
    
    if (error) {
      return res.status(500).json({ error: 'Failed to update user' });
    }
    
    res.json({ message: 'User updated successfully', user: data });
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// 重置用户用量（每月自动执行）
router.post('/reset-usage', verifyAdmin, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .update({ used_minutes: 0, updated_at: new Date() })
      .neq('plan', 'free'); // 只重置付费用户
    
    if (error) {
      return res.status(500).json({ error: 'Failed to reset usage' });
    }
    
    res.json({ message: 'Usage reset successfully', affectedUsers: data.length });
  } catch (err) {
    console.error('Reset usage error:', err);
    res.status(500).json({ error: 'Failed to reset usage' });
  }
});

module.exports = router;
