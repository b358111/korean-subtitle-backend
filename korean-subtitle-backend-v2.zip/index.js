// Railway 入口文件 - 重定向到 src/index.js
require('./src/index.js');
