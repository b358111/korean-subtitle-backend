const express = require('express');
const { authenticate, checkUsageLimit } = require('../middleware/auth');
const { supabase } = require('../db');

const router = express.Router();

// Kimi API OCR
const recognizeWithKimi = async (base64Image) => {
  const response = await fetch('https://api.moonshot.cn/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.KIMI_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'moonshot-v1-8k-vision-preview',
      messages: [
        {
          role: 'system',
          content: '你是OCR助手。请提取图片中所有可见的文字。只返回文字内容，不要解释。如果没有文字，返回空字符串。'
        },
        {
          role: 'user',
          content: [
            {
              type: 'image_url',
              image_url: { url: base64Image }
            },
            {
              type: 'text',
              text: '提取这张图片中的所有文字，只返回文字内容。'
            }
          ]
        }
      ],
      temperature: 0.1,
    }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error?.message || 'Kimi API error');
  }

  const data = await response.json();
  return data.choices[0]?.message?.content?.trim() || '';
};

// 图片OCR
router.post('/image', authenticate, checkUsageLimit, async (req, res) => {
  try {
    const { image } = req.body;
    const user = req.user;
    
    if (!image) {
      return res.status(400).json({ error: 'Image is required' });
    }
    
    // 调用Kimi API
    const text = await recognizeWithKimi(image);
    
    // 记录用量（图片OCR按次计费，每次0.1分钟）
    const minutesUsed = 0.1;
    
    await supabase.from('usage_logs').insert([{
      user_id: user.id,
      action: 'ocr_image',
      minutes_used: minutesUsed
    }]);
    
    // 更新用户用量
    await supabase
      .from('users')
      .update({ 
        used_minutes: user.used_minutes + minutesUsed,
        updated_at: new Date()
      })
      .eq('id', user.id);
    
    res.json({
      text,
      minutesUsed,
      remainingMinutes: user.monthly_minutes - user.used_minutes - minutesUsed
    });
  } catch (err) {
    console.error('OCR error:', err);
    res.status(500).json({ error: 'OCR processing failed', message: err.message });
  }
});

// 视频硬字幕提取
router.post('/video', authenticate, checkUsageLimit, async (req, res) => {
  try {
    const { frames } = req.body; // frames: array of base64 images
    const user = req.user;
    
    if (!frames || !Array.isArray(frames) || frames.length === 0) {
      return res.status(400).json({ error: 'Frames are required' });
    }
    
    // 检查帧数限制
    if (frames.length > 300) {
      return res.status(400).json({ error: 'Maximum 300 frames allowed' });
    }
    
    // 估算用量（每帧0.05分钟）
    const estimatedMinutes = frames.length * 0.05;
    
    if (user.used_minutes + estimatedMinutes > user.monthly_minutes) {
      return res.status(403).json({ 
        error: 'Insufficient minutes',
        required: estimatedMinutes,
        available: user.monthly_minutes - user.used_minutes
      });
    }
    
    // 处理每一帧
    const subtitles = [];
    let lastText = '';
    
    for (let i = 0; i < frames.length; i++) {
      try {
        const text = await recognizeWithKimi(frames[i]);
        
        // 去重
        if (text && text !== lastText && text.length > 2) {
          subtitles.push({
            frame: i,
            text,
            time: new Date(i * 1000).toISOString().substr(14, 8)
          });
          lastText = text;
        }
      } catch (err) {
        console.error(`Frame ${i} error:`, err);
      }
    }
    
    // 记录实际用量
    const actualMinutes = frames.length * 0.05;
    
    await supabase.from('usage_logs').insert([{
      user_id: user.id,
      action: 'ocr_video',
      minutes_used: actualMinutes,
      details: { framesProcessed: frames.length, subtitlesFound: subtitles.length }
    }]);
    
    // 更新用户用量
    await supabase
      .from('users')
      .update({ 
        used_minutes: user.used_minutes + actualMinutes,
        updated_at: new Date()
      })
      .eq('id', user.id);
    
    res.json({
      subtitles,
      framesProcessed: frames.length,
      minutesUsed: actualMinutes,
      remainingMinutes: user.monthly_minutes - user.used_minutes - actualMinutes
    });
  } catch (err) {
    console.error('Video OCR error:', err);
    res.status(500).json({ error: 'Video OCR processing failed', message: err.message });
  }
});

module.exports = router;
