const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { authenticate } = require('../middleware/auth');
const { supabase } = require('../db');

const router = express.Router();

// 定价方案配置
const PLANS = {
  basic: {
    name: 'Basic',
    priceMonthly: 78, // HKD ~$10
    priceYearly: 780, // HKD ~$100
    monthlyMinutes: 90, // 1.5 hours
    storageLimitMB: 10240, // 10GB
  },
  pro: {
    name: 'Pro',
    priceMonthly: 118, // HKD ~$15
    priceYearly: 1180, // HKD ~$150
    monthlyMinutes: 180, // 3 hours
    storageLimitMB: 51200, // 50GB
  },
  premium: {
    name: 'Premium',
    priceMonthly: 312, // HKD ~$40
    priceYearly: 3120, // HKD ~$400
    monthlyMinutes: 600, // 10 hours
    storageLimitMB: 102400, // 100GB
  }
};

// 创建订阅
router.post('/create-subscription', authenticate, async (req, res) => {
  try {
    const user = req.user;
    const { planId, billingCycle } = req.body; // planId: 'basic', 'pro', 'premium', billingCycle: 'monthly' | 'yearly'
    
    if (!PLANS[planId]) {
      return res.status(400).json({ error: 'Invalid plan' });
    }
    
    const plan = PLANS[planId];
    const price = billingCycle === 'yearly' ? plan.priceYearly : plan.priceMonthly;
    
    // 创建或获取Stripe客户
    let customerId = user.stripe_customer_id;
    
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.name,
        metadata: {
          userId: user.id
        }
      });
      customerId = customer.id;
      
      // 保存到数据库
      await supabase
        .from('users')
        .update({ stripe_customer_id: customerId })
        .eq('id', user.id);
    }
    
    // 创建Checkout Session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      line_items: [{
        price_data: {
          currency: 'hkd',
          product_data: {
            name: `CantoSub AI ${plan.name} Plan`,
            description: `${plan.monthlyMinutes} minutes/month, ${plan.storageLimitMB / 1024}GB storage`,
          },
          unit_amount: price * 100, // Stripe uses cents
          recurring: {
            interval: billingCycle === 'yearly' ? 'year' : 'month',
          },
        },
        quantity: 1,
      }],
      mode: 'subscription',
      success_url: `${process.env.FRONTEND_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/pricing`,
      metadata: {
        userId: user.id,
        planId: planId,
      },
    });
    
    res.json({
      sessionId: session.id,
      url: session.url
    });
  } catch (err) {
    console.error('Create subscription error:', err);
    res.status(500).json({ error: 'Failed to create subscription', message: err.message });
  }
});

// Stripe Webhook处理
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
  
  let event;
  
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  
  // 处理事件
  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const userId = session.metadata.userId;
      const planId = session.metadata.planId;
      const plan = PLANS[planId];
      
      // 更新用户订阅
      await supabase
        .from('users')
        .update({
          plan: planId,
          monthly_minutes: plan.monthlyMinutes,
          storage_limit_mb: plan.storageLimitMB,
          stripe_subscription_id: session.subscription,
          subscription_status: 'active',
          subscription_current_period_end: new Date(session.subscription_details?.current_period_end * 1000),
          updated_at: new Date()
        })
        .eq('id', userId);
      
      // 记录支付
      await supabase.from('payments').insert([{
        user_id: userId,
        stripe_payment_intent_id: session.payment_intent,
        amount: session.amount_total / 100,
        currency: session.currency,
        status: 'completed',
        description: `Subscription to ${plan.name} plan`
      }]);
      
      break;
    }
    
    case 'invoice.payment_succeeded': {
      const invoice = event.data.object;
      
      // 记录支付
      await supabase.from('payments').insert([{
        stripe_invoice_id: invoice.id,
        amount: invoice.amount_paid / 100,
        currency: invoice.currency,
        status: 'completed',
        description: 'Subscription renewal'
      });
      
      break;
    }
    
    case 'customer.subscription.deleted': {
      const subscription = event.data.object;
      
      // 获取用户
      const { data: user } = await supabase
        .from('users')
        .select('id')
        .eq('stripe_subscription_id', subscription.id)
        .single();
      
      if (user) {
        // 降级到免费计划
        await supabase
          .from('users')
          .update({
            plan: 'free',
            monthly_minutes: 30,
            storage_limit_mb: 1024,
            subscription_status: 'canceled',
            stripe_subscription_id: null,
            updated_at: new Date()
          })
          .eq('id', user.id);
      }
      
      break;
    }
  }
  
  res.json({ received: true });
});

// 获取用户订阅信息
router.get('/subscription', authenticate, async (req, res) => {
  try {
    const user = req.user;
    
    // 获取最近的支付记录
    const { data: payments } = await supabase
      .from('payments')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10);
    
    res.json({
      plan: user.plan,
      status: user.subscription_status,
      currentPeriodEnd: user.subscription_current_period_end,
      monthlyMinutes: user.monthly_minutes,
      usedMinutes: user.used_minutes,
      payments: payments || []
    });
  } catch (err) {
    console.error('Get subscription error:', err);
    res.status(500).json({ error: 'Failed to get subscription info' });
  }
});

// 取消订阅
router.post('/cancel-subscription', authenticate, async (req, res) => {
  try {
    const user = req.user;
    
    if (!user.stripe_subscription_id) {
      return res.status(400).json({ error: 'No active subscription' });
    }
    
    // 在Stripe中取消（在周期结束时）
    await stripe.subscriptions.update(user.stripe_subscription_id, {
      cancel_at_period_end: true
    });
    
    res.json({ message: 'Subscription will be canceled at the end of the billing period' });
  } catch (err) {
    console.error('Cancel subscription error:', err);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
});

module.exports = router;
