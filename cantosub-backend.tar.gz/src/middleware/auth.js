const jwt = require('jsonwebtoken');
const { supabase } = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// 验证JWT令牌
const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }
    
    const token = authHeader.substring(7);
    
    // 验证JWT
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // 获取用户信息
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', decoded.userId)
      .single();
    
    if (error || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    
    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// 检查用量限制
const checkUsageLimit = async (req, res, next) => {
  try {
    const user = req.user;
    
    // 检查订阅状态
    if (user.subscription_status !== 'active' && user.plan !== 'free') {
      return res.status(403).json({ 
        error: 'Subscription expired',
        message: 'Please renew your subscription'
      });
    }
    
    // 检查分钟数限制
    if (user.used_minutes >= user.monthly_minutes) {
      return res.status(403).json({ 
        error: 'Monthly limit exceeded',
        used: user.used_minutes,
        limit: user.monthly_minutes,
        message: 'You have reached your monthly limit'
      });
    }
    
    // 检查存储限制
    if (user.storage_used_mb >= user.storage_limit_mb) {
      return res.status(403).json({ 
        error: 'Storage limit exceeded',
        used: user.storage_used_mb,
        limit: user.storage_limit_mb,
        message: 'You have reached your storage limit'
      });
    }
    
    next();
  } catch (err) {
    console.error('Usage check error:', err);
    return res.status(500).json({ error: 'Failed to check usage limits' });
  }
};

// 生成JWT
const generateToken = (userId) => {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' });
};

module.exports = { authenticate, checkUsageLimit, generateToken };
