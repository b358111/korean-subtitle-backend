const express = require('express');
const { authenticate } = require('../middleware/auth');
const { supabase } = require('../db');

const router = express.Router();

// 获取用户用量统计
router.get('/stats', authenticate, async (req, res) => {
  try {
    const user = req.user;
    
    // 获取本月用量
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    
    const { data: usageData, error } = await supabase
      .from('usage_logs')
      .select('*')
      .eq('user_id', user.id)
      .gte('created_at', startOfMonth.toISOString())
      .order('created_at', { ascending: false });
    
    if (error) {
      return res.status(500).json({ error: 'Failed to fetch usage data' });
    }
    
    // 统计
    const stats = {
      totalMinutes: 0,
      ocrMinutes: 0,
      uploadSize: 0,
      actions: {}
    };
    
    usageData.forEach(log => {
      stats.totalMinutes += parseFloat(log.minutes_used || 0);
      stats.uploadSize += parseFloat(log.file_size_mb || 0);
      
      if (log.action.includes('ocr')) {
        stats.ocrMinutes += parseFloat(log.minutes_used || 0);
      }
      
      stats.actions[log.action] = (stats.actions[log.action] || 0) + 1;
    });
    
    res.json({
      currentPlan: user.plan,
      monthlyMinutes: user.monthly_minutes,
      usedMinutes: user.used_minutes,
      remainingMinutes: user.monthly_minutes - user.used_minutes,
      storageUsed: user.storage_used_mb,
      storageLimit: user.storage_limit_mb,
      storageRemaining: user.storage_limit_mb - user.storage_used_mb,
      thisMonth: {
        minutesUsed: stats.totalMinutes,
        ocrMinutes: stats.ocrMinutes,
        uploadSizeMB: stats.uploadSize,
        actions: stats.actions
      },
      recentUsage: usageData.slice(0, 20).map(log => ({
        action: log.action,
        minutes: log.minutes_used,
        fileSize: log.file_size_mb,
        createdAt: log.created_at
      }))
    });
  } catch (err) {
    console.error('Get usage stats error:', err);
    res.status(500).json({ error: 'Failed to get usage stats' });
  }
});

// 获取用量历史
router.get('/history', authenticate, async (req, res) => {
  try {
    const user = req.user;
    const { page = 1, limit = 50 } = req.query;
    
    const offset = (page - 1) * limit;
    
    const { data: logs, error, count } = await supabase
      .from('usage_logs')
      .select('*', { count: 'exact' })
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) {
      return res.status(500).json({ error: 'Failed to fetch usage history' });
    }
    
    res.json({
      logs: logs.map(log => ({
        id: log.id,
        action: log.action,
        minutes: log.minutes_used,
        fileSize: log.file_size_mb,
        details: log.details,
        createdAt: log.created_at
      })),
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: count,
        totalPages: Math.ceil(count / limit)
      }
    });
  } catch (err) {
    console.error('Get usage history error:', err);
    res.status(500).json({ error: 'Failed to get usage history' });
  }
});

module.exports = router;
