const express = require('express');
const bcrypt = require('bcryptjs');
const { supabase } = require('../db');
const { authenticate, generateToken } = require('../middleware/auth');

const router = express.Router();

// 注册
router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    // 验证输入
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    
    // 检查邮箱是否已存在
    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('email', email)
      .single();
    
    if (existingUser) {
      return res.status(409).json({ error: 'Email already registered' });
    }
    
    // 加密密码
    const passwordHash = await bcrypt.hash(password, 10);
    
    // 创建用户
    const { data: user, error } = await supabase
      .from('users')
      .insert([{
        email,
        name: name || email.split('@')[0],
        password_hash: passwordHash,
        plan: 'free',
        monthly_minutes: 30,
        storage_limit_mb: 1024
      }])
      .select()
      .single();
    
    if (error) {
      console.error('Registration error:', error);
      return res.status(500).json({ error: 'Failed to create user' });
    }
    
    // 生成令牌
    const token = generateToken(user.id);
    
    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        plan: user.plan,
        monthlyMinutes: user.monthly_minutes,
        usedMinutes: user.used_minutes,
        storageUsed: user.storage_used_mb,
        storageLimit: user.storage_limit_mb
      }
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// 登录
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    
    // 查找用户
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();
    
    if (error || !user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // 验证密码
    const isValid = await bcrypt.compare(password, user.password_hash);
    
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // 生成令牌
    const token = generateToken(user.id);
    
    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        plan: user.plan,
        monthlyMinutes: user.monthly_minutes,
        usedMinutes: user.used_minutes,
        storageUsed: user.storage_used_mb,
        storageLimit: user.storage_limit_mb
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// 获取当前用户信息
router.get('/me', authenticate, async (req, res) => {
  try {
    const user = req.user;
    
    res.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        plan: user.plan,
        monthlyMinutes: user.monthly_minutes,
        usedMinutes: user.used_minutes,
        storageUsed: user.storage_used_mb,
        storageLimit: user.storage_limit_mb,
        subscriptionStatus: user.subscription_status
      }
    });
  } catch (err) {
    console.error('Get user error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Google OAuth 回调（简化版，实际需要使用passport-google-oauth）
router.post('/google', async (req, res) => {
  try {
    const { email, name, googleId } = req.body;
    
    // 检查用户是否已存在
    let { data: user } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();
    
    if (!user) {
      // 创建新用户
      const { data: newUser, error } = await supabase
        .from('users')
        .insert([{
          email,
          name: name || email.split('@')[0],
          plan: 'free',
          monthly_minutes: 30,
          storage_limit_mb: 1024
        }])
        .select()
        .single();
      
      if (error) {
        return res.status(500).json({ error: 'Failed to create user' });
      }
      
      user = newUser;
    }
    
    const token = generateToken(user.id);
    
    res.json({
      message: 'Google login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        plan: user.plan,
        monthlyMinutes: user.monthly_minutes,
        usedMinutes: user.used_minutes,
        storageUsed: user.storage_used_mb,
        storageLimit: user.storage_limit_mb
      }
    });
  } catch (err) {
    console.error('Google auth error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
